import React from 'react';

interface SpinnerProps {
    size?: 'sm' | 'md' | 'lg';
}

const Spinner: React.FC<SpinnerProps> = ({ size = 'md' }) => {
    const sizeClasses = {
        sm: 'h-6 w-6',
        md: 'h-12 w-12',
        lg: 'h-24 w-24'
    };

    return (
        <div className="flex justify-center items-center p-4">
            <div className={`${sizeClasses[size]} border-4 border-dark-surface border-t-brand-accent rounded-full animate-spin`}></div>
        </div>
    );
};

export default Spinner;
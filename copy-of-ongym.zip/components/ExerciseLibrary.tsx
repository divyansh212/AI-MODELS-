import React, { useState } from 'react';
import { getExerciseTutorial } from '../services/geminiService';
import Card from './ui/Card';
import Button from './ui/Button';
import Spinner from './ui/Spinner';

interface TutorialData {
    setup: string;
    execution: string;
    mistakes: string;
    youtubeVideoId: string;
}

const ExerciseLibrary: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [tutorial, setTutorial] = useState<TutorialData | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSearch = async () => {
        if (!searchTerm.trim()) {
            setError('Please enter an exercise name.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setTutorial(null);
        try {
            const resultText = await getExerciseTutorial(searchTerm);
            const resultData: TutorialData = JSON.parse(resultText);
            setTutorial(resultData);
        } catch (err) {
            setError('Could not fetch tutorial. Please try again.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-center text-dark-text-primary">Exercise Library</h2>
            <p className="text-center text-dark-text-secondary">Search for any exercise or machine to get a step-by-step tutorial.</p>

            <Card>
                <div className="flex flex-col sm:flex-row gap-4">
                    <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="e.g., Barbell Squat"
                        className="flex-grow p-3 bg-dark-bg border border-dark-surface rounded-lg focus:ring-brand-accent focus:border-brand-accent"
                        onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                        aria-label="Search for an exercise"
                    />
                    <Button onClick={handleSearch} isLoading={isLoading} className="sm:w-auto w-full">
                        Search
                    </Button>
                </div>
            </Card>
            
            {isLoading && <Spinner />}
            {error && <Card><p className="text-red-400 text-center">{error}</p></Card>}

            {tutorial && (
                <Card className="animate-fade-in">
                    <h3 className="text-2xl font-bold mb-4 text-center capitalize">{searchTerm}</h3>
                    
                    <div className="relative w-full pb-[56.25%] mb-6 rounded-lg overflow-hidden shadow-lg bg-dark-surface">
                         <iframe
                            className="absolute top-0 left-0 w-full h-full"
                            src={`https://www.youtube.com/embed/${tutorial.youtubeVideoId}`}
                            title="YouTube video player"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    <div className="prose prose-invert text-dark-text-secondary max-w-none space-y-4">
                        <div>
                            <h4 className="text-lg font-semibold text-brand-accent mb-2">Setup</h4>
                            <p>{tutorial.setup}</p>
                        </div>
                         <div>
                            <h4 className="text-lg font-semibold text-brand-accent mb-2">Execution</h4>
                            <p>{tutorial.execution}</p>
                        </div>
                         <div>
                            <h4 className="text-lg font-semibold text-brand-accent mb-2">Common Mistakes</h4>
                            <p>{tutorial.mistakes}</p>
                        </div>
                    </div>
                </Card>
            )}
        </div>
    );
};

export default ExerciseLibrary;
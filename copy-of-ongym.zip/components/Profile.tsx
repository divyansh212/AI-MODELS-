import React, { useState, useRef } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Spinner from './ui/Spinner';
import { generateWorkoutPlan } from '../services/geminiService';
import type { User, WorkoutPlan } from '../types';

interface ProfileProps {
    user?: User | null;
    plan?: WorkoutPlan | null;
    onProfileSave: (user: User, plan: WorkoutPlan) => void;
}

const goals = ['Build Muscle', 'Lose Fat', 'Improve Endurance', 'General Fitness'];

const Profile: React.FC<ProfileProps> = ({ user, plan, onProfileSave }) => {
    const [formData, setFormData] = useState<Partial<User>>({
        name: user?.name || 'Fitness Enthusiast',
        goal: user?.goal || goals[0],
        weight: user?.weight || 70,
        height: user?.height || 175,
        workoutDays: user?.workoutDays || 3,
        workoutHours: user?.workoutHours || 1,
        photoUrl: user?.photoUrl || '',
    });
    const [photoFile, setPhotoFile] = useState<File | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'weight' || name === 'height' || name === 'workoutDays' || name === 'workoutHours' ? parseFloat(value) : value }));
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setPhotoFile(file);
            setFormData(prev => ({ ...prev, photoUrl: URL.createObjectURL(file) }));
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.goal || !formData.weight || !formData.height || !formData.workoutDays || !formData.workoutHours) {
            setError("Please fill out all fields.");
            return;
        }

        setIsLoading(true);
        setError(null);
        
        try {
            const newUser: User = formData as User;
            const planText = await generateWorkoutPlan(newUser);
            const newPlan: WorkoutPlan = JSON.parse(planText);
            onProfileSave(newUser, newPlan);
        } catch (err) {
            setError("Failed to create profile and generate plan. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    // Onboarding View
    if (!user) {
        return (
            <div className="space-y-6 max-w-lg mx-auto">
                <h2 className="text-3xl font-bold text-center text-dark-text-primary">Create Your Profile</h2>
                <p className="text-center text-dark-text-secondary">Tell us about yourself to generate a personalized AI fitness plan.</p>
                <form onSubmit={handleSubmit}>
                    <Card className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-dark-text-secondary mb-2">Primary Goal</label>
                            <select name="goal" value={formData.goal} onChange={handleChange} className="w-full p-3 bg-dark-bg border border-dark-surface rounded-lg focus:ring-brand-accent focus:border-brand-accent">
                                {goals.map(g => <option key={g} value={g}>{g}</option>)}
                            </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-dark-text-secondary mb-2">Weight (kg)</label>
                                <input type="number" name="weight" value={formData.weight} onChange={handleChange} className="w-full p-3 bg-dark-bg border border-dark-surface rounded-lg" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-dark-text-secondary mb-2">Height (cm)</label>
                                <input type="number" name="height" value={formData.height} onChange={handleChange} className="w-full p-3 bg-dark-bg border border-dark-surface rounded-lg" />
                            </div>
                        </div>
                         <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-dark-text-secondary mb-2">Workout Days/Week</label>
                                <input type="number" name="workoutDays" min="1" max="7" value={formData.workoutDays} onChange={handleChange} className="w-full p-3 bg-dark-bg border border-dark-surface rounded-lg" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-dark-text-secondary mb-2">Hours/Session</label>
                                <input type="number" name="workoutHours" min="0.5" max="3" step="0.5" value={formData.workoutHours} onChange={handleChange} className="w-full p-3 bg-dark-bg border border-dark-surface rounded-lg" />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-dark-text-secondary mb-2">Profile Photo (Optional)</label>
                             <input type="file" accept="image/*" onChange={handleFileChange} ref={fileInputRef} className="hidden" />
                            <Button type="button" onClick={() => fileInputRef.current?.click()} variant="secondary" className="w-full">
                                {formData.photoUrl ? 'Change Photo' : 'Upload Photo'}
                            </Button>
                            {formData.photoUrl && <img src={formData.photoUrl} alt="Profile preview" className="mt-4 rounded-full h-24 w-24 mx-auto object-cover" />}
                        </div>
                        <Button type="submit" isLoading={isLoading} className="w-full text-lg py-4">Save Profile & Generate Plan</Button>
                        {error && <p className="text-red-400 text-center text-sm mt-2">{error}</p>}
                    </Card>
                </form>
            </div>
        );
    }
    
    // Display View
    return (
         <div className="space-y-6">
            <h2 className="text-3xl font-bold text-center text-dark-text-primary">My Profile</h2>
             <Card className="flex flex-col items-center">
                <img src={user.photoUrl || `https://api.dicebear.com/8.x/bottts/svg?seed=${user.name}`} alt="Profile" className="rounded-full h-32 w-32 object-cover shadow-lg border-4 border-dark-surface" />
                <h3 className="text-2xl font-bold mt-4">{user.name}</h3>
                <p className="text-brand-accent font-semibold mt-1">{user.goal}</p>
                <div className="flex space-x-8 mt-6 text-center">
                    <div>
                        <p className="text-2xl font-bold">{user.weight}<span className="text-sm">kg</span></p>
                        <p className="text-xs text-dark-text-secondary">Weight</p>
                    </div>
                     <div>
                        <p className="text-2xl font-bold">{user.height}<span className="text-sm">cm</span></p>
                        <p className="text-xs text-dark-text-secondary">Height</p>
                    </div>
                     <div>
                        <p className="text-2xl font-bold">{user.workoutDays}</p>
                        <p className="text-xs text-dark-text-secondary">Days/Week</p>
                    </div>
                </div>
                 <Button onClick={() => alert("Edit profile feature coming soon!")} variant="secondary" className="mt-8 w-full max-w-xs">
                    Edit Profile
                </Button>
            </Card>
         </div>
    );
};

export default Profile;

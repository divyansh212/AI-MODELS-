import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import Card from './ui/Card';
import Button from './ui/Button';
import type { FoodLogEntry, WorkoutSession, User, WorkoutPlan } from '../types';
import type { Tab } from '../App';

interface ProgressTrackerProps {
    foodLog: FoodLogEntry[];
    workoutHistory: WorkoutSession[];
    setActiveTab: (tab: Tab) => void;
    user: User;
    plan: WorkoutPlan;
}

const StatCard: React.FC<{ value: string | number; label: string; isLast?: boolean }> = ({ value, label, isLast = false }) => (
    <div className={`flex-1 p-4 flex flex-col items-center justify-center text-center ${!isLast ? 'border-r border-gray-800' : ''}`}>
        <p className="text-2xl font-bold text-white">
            {value}
        </p>
        <p className="text-xs text-dark-text-secondary mt-1">{label}</p>
    </div>
);

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ foodLog, workoutHistory, setActiveTab, user, plan }) => {

    const totalCaloriesToday = useMemo(() => {
        const today = new Date().toLocaleDateString();
        return foodLog
            .filter(entry => entry.date.toLocaleDateString() === today)
            .reduce((sum, entry) => sum + entry.calories, 0);
    }, [foodLog]);

    const workoutsThisWeek = useMemo(() => {
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
        return workoutHistory.filter(session => session.date > oneWeekAgo).length;
    }, [workoutHistory]);

    const lastWorkoutDate = useMemo(() => {
        if (workoutHistory.length === 0) return null;
        return workoutHistory.sort((a, b) => b.date.getTime() - a.date.getTime())[0].date;
    }, [workoutHistory]);
    
    const daysSinceLastWorkout = useMemo(() => {
        if (!lastWorkoutDate) return Infinity;
        const diffTime = Math.abs(new Date().getTime() - lastWorkoutDate.getTime());
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }, [lastWorkoutDate]);

    const weeklyProgressData = [
        { day: 'M', progress: 10 }, { day: 'T', progress: 15 }, { day: 'W', progress: 13 },
        { day: 'T', progress: 18 }, { day: 'F', progress: 16 }, { day: 'S', progress: 20 },
        { day: 'S', progress: 22 },
    ];

    return (
        <div className="space-y-8">
            <h1 className="text-4xl font-bold text-left text-white">Dashboard</h1>
            
            <Card className="!p-0">
                <div className="flex">
                    <StatCard value={totalCaloriesToday} label="Kcal Today" />
                    <StatCard value={workoutsThisWeek} label={`Workouts / ${user.workoutDays} This Week`} />
                    <StatCard value={plan.goalDeadline} label="Goal Deadline" isLast={true} />
                </div>
            </Card>

            {daysSinceLastWorkout > 2 && (
                 <Card className="bg-yellow-900/30 border border-yellow-600">
                    <h3 className="text-lg font-semibold text-yellow-400">Stay on Track!</h3>
                    <p className="text-yellow-500 text-sm mt-1">
                        It's been a few days since your last workout. Consistency is key to reaching your goal of <span className="font-bold">{user.goal}</span>. Let's get moving!
                    </p>
                </Card>
            )}
            
            <Card>
                <h3 className="text-xl font-semibold mb-4 text-white">Workout Progress</h3>
                <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={weeklyProgressData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                         <defs>
                            <linearGradient id="colorProgress" x1="0" y1="0" x2="1" y2="0">
                                <stop offset="5%" stopColor="#84cc16" stopOpacity={0.9}/>
                                <stop offset="95%" stopColor="#2563eb" stopOpacity={0.9}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#373737" vertical={false} />
                        <XAxis dataKey="day" stroke="#8E8E93" axisLine={false} tickLine={false} />
                        <YAxis stroke="#8E8E93" axisLine={false} tickLine={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', border: 'none', borderRadius: '8px' }} />
                        <Line type="monotone" dataKey="progress" stroke="url(#colorProgress)" strokeWidth={4} dot={false} activeDot={{ r: 6, fill: '#D9EF0C', stroke: '#000', strokeWidth: 2 }} />
                    </LineChart>
                </ResponsiveContainer>
            </Card>

            <div className="space-y-4">
                 <Button onClick={() => setActiveTab('workouts')} variant="primary" className="w-full text-lg py-4">
                    START WORKOUT
                </Button>
                <Button onClick={() => setActiveTab('nutrition')} variant="secondary" className="w-full text-lg py-4">
                    Track Nutrition
                </Button>
            </div>
        </div>
    );
};

export default ProgressTracker;

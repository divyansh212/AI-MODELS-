import React, { useState, useRef } from 'react';
import { getCalorieInfo } from '../services/geminiService';
import Card from './ui/Card';
import Button from './ui/Button';
import Spinner from './ui/Spinner';
import type { FoodLogEntry } from '../types';

interface CalorieCounterProps {
    onLogEntry: (entry: Omit<FoodLogEntry, 'id' | 'date'>) => void;
}

interface NutritionInfo {
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    error?: string;
}

const CalorieCounter: React.FC<CalorieCounterProps> = ({ onLogEntry }) => {
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [result, setResult] = useState<NutritionInfo | null>(null);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setImageFile(file);
            setPreviewUrl(URL.createObjectURL(file));
            setResult(null);
            setError(null);
        }
    };

    const handleAnalyze = async () => {
        if (!imageFile) {
            setError("Please select an image first.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const responseText = await getCalorieInfo(imageFile);
            const data: NutritionInfo = JSON.parse(responseText);
            if (data.error) {
                setError(data.error);
            } else {
                setResult(data);
            }
        } catch (err) {
            setError("Failed to parse analysis results. Please try a different image.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleLog = () => {
        if (result) {
            onLogEntry({
                name: result.name,
                calories: result.calories,
                protein: result.protein,
                carbs: result.carbs,
                fat: result.fat,
            });
            // Reset for next entry
            setResult(null);
            setImageFile(null);
            setPreviewUrl(null);
            if(fileInputRef.current) fileInputRef.current.value = "";
        }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-center text-dark-text-primary">Track Nutrition</h2>
            <p className="text-center text-dark-text-secondary">Upload a photo of your meal to get an instant nutritional analysis.</p>

            <Card className="text-center">
                <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    className="hidden"
                    aria-label="Upload food photo"
                />
                <Button onClick={() => fileInputRef.current?.click()} variant="secondary">
                    {previewUrl ? 'Change Image' : 'Select Image'}
                </Button>

                {previewUrl && (
                    <div className="mt-6 flex justify-center">
                        <img src={previewUrl} alt="Food preview" className="rounded-lg max-h-64 shadow-lg" />
                    </div>
                )}
            </Card>

            {imageFile && !result && (
                <div className="text-center">
                    <Button onClick={handleAnalyze} isLoading={isLoading}>
                        Analyze Meal
                    </Button>
                </div>
            )}

            {isLoading && <Spinner />}

            {error && <Card><p className="text-red-400 text-center">{error}</p></Card>}

            {result && (
                <Card className="animate-fade-in">
                    <h3 className="text-2xl font-bold text-brand-accent mb-4 text-center">{result.name}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                        <div className="bg-dark-bg p-4 rounded-lg">
                            <p className="text-sm text-dark-text-secondary">Calories</p>
                            <p className="text-2xl font-bold">{result.calories}</p>
                        </div>
                        <div className="bg-dark-bg p-4 rounded-lg">
                            <p className="text-sm text-dark-text-secondary">Protein</p>
                            <p className="text-2xl font-bold">{result.protein}g</p>
                        </div>
                        <div className="bg-dark-bg p-4 rounded-lg">
                            <p className="text-sm text-dark-text-secondary">Carbs</p>
                            <p className="text-2xl font-bold">{result.carbs}g</p>
                        </div>
                        <div className="bg-dark-bg p-4 rounded-lg">
                            <p className="text-sm text-dark-text-secondary">Fat</p>
                            <p className="text-2xl font-bold">{result.fat}g</p>
                        </div>
                    </div>
                    <div className="mt-6 text-center">
                        <Button onClick={handleLog} variant="primary">Log Meal</Button>
                    </div>
                </Card>
            )}
        </div>
    );
};

export default CalorieCounter;
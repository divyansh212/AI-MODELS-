import React from 'react';
import Button from './ui/Button';
import Card from './ui/Card';

interface LoginProps {
    onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
    return (
        <div className="min-h-screen bg-dark-bg font-sans flex flex-col justify-center items-center p-4">
            <div className="w-full max-w-md text-center">
                <h1 className="text-5xl font-black text-white">
                    FitForge <span className="text-brand-accent">AI</span>
                </h1>
                <p className="mt-4 text-lg text-dark-text-secondary">
                    Your personal AI-powered fitness and nutrition coach.
                </p>
                <Card className="mt-12">
                    <div className="space-y-4">
                         <h2 className="text-2xl font-bold text-white">Welcome</h2>
                         <p className="text-dark-text-secondary">
                            Let's start your journey to a healthier you. Forge your new body with the power of AI.
                         </p>
                        <Button onClick={onLogin} className="w-full text-lg py-4 mt-4" variant="primary">
                            Get Started
                        </Button>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default Login;

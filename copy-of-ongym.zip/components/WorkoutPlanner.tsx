import React from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import type { WorkoutPlan, WorkoutSession } from '../types';

interface WorkoutPlannerProps {
    plan: WorkoutPlan | null;
    onStartWorkout: (session: Omit<WorkoutSession, 'id' | 'date'>) => void;
}

const WorkoutPlanner: React.FC<WorkoutPlannerProps> = ({ plan, onStartWorkout }) => {
    
    const handleStartWorkout = (dayIndex: number) => {
        if(plan) {
            const sessionDay = plan.days[dayIndex];
            onStartWorkout({
                planName: plan.goal,
                day: sessionDay.day,
                exercises: sessionDay.exercises,
            });
            alert(`Workout "${sessionDay.day}" started! Check your progress on the Home tab.`);
        }
    }

    if (!plan) {
        return (
            <Card>
                <p className="text-center text-dark-text-secondary">Your workout plan is being generated. Go to your profile to create one!</p>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <h3 className="text-2xl font-bold text-center text-brand-accent">Your Plan: {plan.goal}</h3>
            <p className="text-center text-dark-text-secondary">Target Deadline: <span className="font-bold text-white">{plan.goalDeadline}</span></p>

            {plan.days.map((day, dayIndex) => (
                <Card key={dayIndex}>
                    <h4 className="text-xl font-semibold mb-4 text-dark-text-primary">{day.day}</h4>
                    <ul className="space-y-3">
                        {day.exercises.map((exercise, exIndex) => (
                            <li key={exIndex} className="p-3 bg-dark-bg rounded-lg flex justify-between items-center">
                                <div>
                                    <p className="font-medium">{exercise.name}</p>
                                    <p className="text-sm text-dark-text-secondary">{exercise.sets} sets of {exercise.reps} reps</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                    <div className="mt-4 text-right">
                        <Button onClick={() => handleStartWorkout(dayIndex)} variant="secondary">Start Workout</Button>
                    </div>
                </Card>
            ))}
        </div>
    );
};

export default WorkoutPlanner;

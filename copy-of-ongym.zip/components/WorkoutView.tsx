import React, { useState } from 'react';
import WorkoutPlanner from './WorkoutPlanner';
import ExerciseLibrary from './ExerciseLibrary';
import type { WorkoutPlan, WorkoutSession } from '../types';

interface WorkoutViewProps {
    plan: WorkoutPlan | null;
    onStartWorkout: (session: Omit<WorkoutSession, 'id' | 'date'>) => void;
}

type WorkoutTab = 'plan' | 'library';

const WorkoutView: React.FC<WorkoutViewProps> = ({ plan, onStartWorkout }) => {
    const [activeTab, setActiveTab] = useState<WorkoutTab>('plan');

    return (
        <div className="space-y-6">
            <div className="flex justify-center p-1 bg-dark-surface rounded-lg">
                <button
                    onClick={() => setActiveTab('plan')}
                    className={`w-full font-semibold py-2 px-4 rounded-md transition-colors duration-200 ${
                        activeTab === 'plan' ? 'bg-brand-accent text-black' : 'text-dark-text-secondary hover:text-white'
                    }`}
                >
                    My Plan
                </button>
                <button
                    onClick={() => setActiveTab('library')}
                    className={`w-full font-semibold py-2 px-4 rounded-md transition-colors duration-200 ${
                        activeTab === 'library' ? 'bg-brand-accent text-black' : 'text-dark-text-secondary hover:text-white'
                    }`}
                >
                    Exercise Library
                </button>
            </div>
            
            <div>
                {activeTab === 'plan' ? (
                    <WorkoutPlanner plan={plan} onStartWorkout={onStartWorkout} />
                ) : (
                    <ExerciseLibrary />
                )}
            </div>
        </div>
    );
};

export default WorkoutView;

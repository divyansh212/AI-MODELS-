import React, { useState, useCallback } from 'react';
import CalorieCounter from './components/CalorieCounter';
import ProgressTracker from './components/ProgressTracker';
import { HomeIcon, WorkoutIcon, NutritionIcon, ProfileIcon } from './components/Icons';
import type { FoodLogEntry, WorkoutSession, User, WorkoutPlan } from './types';
import Login from './components/Login';
import Profile from './components/Profile';
import WorkoutView from './components/WorkoutView';

export type Tab = 'home' | 'workouts' | 'nutrition' | 'profile';

const App: React.FC = () => {
    const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
    const [user, setUser] = useState<User | null>(null);
    const [plan, setPlan] = useState<WorkoutPlan | null>(null);

    const [activeTab, setActiveTab] = useState<Tab>('home');
    const [foodLog, setFoodLog] = useState<FoodLogEntry[]>([]);
    const [workoutHistory, setWorkoutHistory] = useState<WorkoutSession[]>([]);

    const addFoodLogEntry = useCallback((entry: Omit<FoodLogEntry, 'id' | 'date'>) => {
        setFoodLog(prevLog => [...prevLog, { ...entry, id: Date.now(), date: new Date() }]);
    }, []);

    const addWorkoutSession = useCallback((session: Omit<WorkoutSession, 'id' | 'date'>) => {
        setWorkoutHistory(prevHistory => [...prevHistory, { ...session, id: Date.now(), date: new Date() }]);
    }, []);
    
    const handleLogin = () => {
        // In a real app, this would involve authentication
        setIsLoggedIn(true);
    };

    const handleProfileSave = (newUser: User, newPlan: WorkoutPlan) => {
        setUser(newUser);
        setPlan(newPlan);
    };


    if (!isLoggedIn) {
        return <Login onLogin={handleLogin} />;
    }

    if (!user || !plan) {
        return <Profile onProfileSave={handleProfileSave} />;
    }


    const renderContent = () => {
        switch (activeTab) {
            case 'home':
                return <ProgressTracker foodLog={foodLog} workoutHistory={workoutHistory} setActiveTab={setActiveTab} user={user} plan={plan} />;
            case 'nutrition':
                return <CalorieCounter onLogEntry={addFoodLogEntry} />;
            case 'workouts':
                return <WorkoutView plan={plan} onStartWorkout={addWorkoutSession} />;
            case 'profile':
                return <Profile user={user} plan={plan} onProfileSave={handleProfileSave} />;
            default:
                return <ProgressTracker foodLog={foodLog} workoutHistory={workoutHistory} setActiveTab={setActiveTab} user={user} plan={plan}/>;
        }
    };
    
    const navItems = [
        { id: 'home', label: 'Home', icon: <HomeIcon /> },
        { id: 'workouts', label: 'Workouts', icon: <WorkoutIcon /> },
        { id: 'nutrition', label: 'Nutrition', icon: <NutritionIcon /> },
        { id: 'profile', label: 'Profile', icon: <ProfileIcon /> },
    ];

    return (
        <div className="min-h-screen bg-dark-bg font-sans flex flex-col">
            <main className="flex-grow p-4 md:p-6 mb-20">
                {renderContent()}
            </main>

            <nav className="fixed bottom-0 left-0 right-0 bg-dark-surface border-t border-black shadow-lg">
                <div className="flex justify-around max-w-lg mx-auto">
                    {navItems.map((item) => (
                        <button
                            key={item.id}
                            onClick={() => setActiveTab(item.id as Tab)}
                            className={`flex flex-col items-center justify-center w-full pt-3 pb-2 transition-colors duration-200 ${
                                activeTab === item.id ? 'text-brand-accent' : 'text-dark-text-secondary hover:text-brand-accent'
                            }`}
                            aria-label={item.label}
                        >
                            <div className="w-6 h-6 mb-1">{item.icon}</div>
                            <span className="text-xs font-medium">{item.label}</span>
                        </button>
                    ))}
                </div>
            </nav>
        </div>
    );
};

export default App;

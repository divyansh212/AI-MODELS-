import { GoogleGenAI, Type } from "@google/genai";
import type { User } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const model = 'gemini-2.5-flash';

const fileToGenerativePart = async (file: File) => {
    const base64EncodedDataPromise = new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
    });
    return {
        inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
};

export const getCalorieInfo = async (imageFile: File): Promise<string> => {
    try {
        const imagePart = await fileToGenerativePart(imageFile);
        const prompt = `Analyze the food in this image. Provide a detailed nutritional breakdown including a calorie estimate, protein, carbs, and fat. Give a name to the food item. Format the response as a JSON object with keys: "name", "calories", "protein", "carbs", "fat". If the image does not contain food, return a JSON object with an "error" key. Example: {"name": "Chicken Salad", "calories": 350, "protein": 30, "carbs": 10, "fat": 20}`;
        
        const response = await ai.models.generateContent({
            model,
            contents: { parts: [imagePart, { text: prompt }] },
            config: {
                responseMimeType: "application/json",
            }
        });
        
        return response.text;
    } catch (error) {
        console.error("Error analyzing food image:", error);
        return JSON.stringify({ error: "Could not analyze image. Please try again." });
    }
};

export const generateWorkoutPlan = async (user: User): Promise<string> => {
    try {
        const bmi = (user.weight / ((user.height / 100) ** 2)).toFixed(1);
        const prompt = `
        You are an expert fitness coach. A user has provided their details:
        - Goal: ${user.goal}
        - Current Weight: ${user.weight} kg
        - Height: ${user.height} cm (BMI: ${bmi})
        - Availability: ${user.workoutDays} days a week, for ${user.workoutHours} hour(s) per session.
        
        Based on this, create a realistic, motivating, and effective ${user.workoutDays}-day split workout routine. 
        Focus on compound movements with some accessory work suitable for their goal.
        Also, calculate a reasonable deadline to achieve a significant milestone for their goal (e.g., lose 5kg, gain 2kg of muscle).
        
        Respond with a JSON object.
        `;
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        goal: { type: Type.STRING },
                        goalDeadline: { 
                            type: Type.STRING,
                            description: "A motivating and realistic time estimate, e.g., '8 Weeks'"
                        },
                        days: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    day: { type: Type.STRING },
                                    exercises: {
                                        type: Type.ARRAY,
                                        items: {
                                            type: Type.OBJECT,
                                            properties: {
                                                name: { type: Type.STRING },
                                                sets: { type: Type.STRING },
                                                reps: { type: Type.STRING }
                                            },
                                            required: ["name", "sets", "reps"]
                                        }
                                    }
                                },
                                required: ["day", "exercises"]
                            }
                        }
                    },
                    required: ["goal", "days", "goalDeadline"]
                }
            }
        });
        
        return response.text;
    } catch (error) {
        console.error("Error generating workout plan:", error);
        throw new Error("Failed to generate workout plan.");
    }
};

export const getExerciseTutorial = async (exerciseName: string): Promise<string> => {
    try {
        const prompt = `
        Provide a tutorial for the exercise: "${exerciseName}".
        - For "setup", describe the starting position and any equipment setup.
        - For "execution", give clear, step-by-step instructions for one repetition.
        - For "mistakes", list common errors to avoid.
        - Provide a relevant YouTube video ID for a tutorial.
        Respond in JSON.`;
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        setup: {
                            type: Type.STRING,
                            description: "Instructions on how to set up for the exercise."
                        },
                        execution: {
                            type: Type.STRING,
                            description: "Step-by-step instructions on how to perform the exercise."
                        },
                        mistakes: {
                            type: Type.STRING,
                            description: "Common mistakes to avoid while performing the exercise."
                        },
                        youtubeVideoId: {
                            type: Type.STRING,
                            description: "A relevant YouTube video ID for the exercise."
                        }
                    },
                    required: ["setup", "execution", "mistakes", "youtubeVideoId"]
                }
            }
        });
        
        return response.text;
    } catch (error) {
        console.error("Error fetching exercise tutorial:", error);
        throw new Error("Failed to fetch exercise tutorial.");
    }
};

export interface FoodLogEntry {
    id: number;
    date: Date;
    name: string;
    calories: number;
    protein?: number;
    carbs?: number;
    fat?: number;
}

export interface Exercise {
    name: string;
    sets: string;
    reps: string;
    completedSets?: { reps: number; weight: number }[];
}

export interface WorkoutDay {
    day: string;
    exercises: Exercise[];
}

export interface WorkoutPlan {
    goal: string;
    days: WorkoutDay[];
    goalDeadline: string;
}

export interface WorkoutSession {
    id: number;
    date: Date;
    planName: string;
    day: string;
    exercises: Exercise[];
}

export interface ProgressData {
    name: string;
    calories: number;
}

export interface User {
    name: string;
    photoUrl: string;
    weight: number;
    height: number;
    goal: string;
    workoutDays: number;
    workoutHours: number;
}
